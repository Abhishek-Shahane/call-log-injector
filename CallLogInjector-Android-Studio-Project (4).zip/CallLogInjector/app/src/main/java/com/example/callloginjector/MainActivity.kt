package com.example.callloginjector

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.CallLog
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Color(0xFF6366F1),
                    onPrimary = Color.White,
                    primaryContainer = Color(0xFFEEF2FF),
                    onPrimaryContainer = Color(0xFF312E81),
                    surface = Color.White
                )
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    CallLogInjectorScreen()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CallLogInjectorScreen() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // 1. UI State with remember & mutableStateOf
    var targetNumber by rememberSaveable { mutableStateOf("+1 555 019 2834") }
    var hoursWindowText by rememberSaveable { mutableStateOf("24") }
    var callCountText by rememberSaveable { mutableStateOf("5") }
    var statusText by rememberSaveable { mutableStateOf("Ready to inject fake calls.") }
    var isSuccess by rememberSaveable { mutableStateOf<Boolean?>(null) }
    var isProcessing by rememberSaveable { mutableStateOf(false) }

    // Required permissions
    val permissionsToRequest = arrayOf(
        Manifest.permission.WRITE_CALL_LOG,
        Manifest.permission.READ_CALL_LOG
    )

    // Helper to run injection on IO dispatcher
    fun performInjection() {
        val hours = hoursWindowText.toIntOrNull() ?: 24
        val count = callCountText.toIntOrNull() ?: 5
        val number = targetNumber.trim()

        if (number.isEmpty()) {
            statusText = "Error: Please enter a target phone number."
            isSuccess = false
            return
        }

        if (count <= 0 || hours <= 0) {
            statusText = "Error: Count and Hours must be positive numbers."
            isSuccess = false
            return
        }

        isProcessing = true
        statusText = "Injecting $count calls into system CallLog..."

        coroutineScope.launch {
            val result = withContext(Dispatchers.IO) {
                injectFakeCalls(
                    context = context,
                    targetNumber = number,
                    hoursWindow = hours,
                    callCount = count
                )
            }

            isProcessing = false
            statusText = result.message
            isSuccess = result.isSuccess

            if (result.isSuccess) {
                Toast.makeText(context, result.message, Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "Injection Failed", Toast.LENGTH_LONG).show()
            }
        }
    }

    // 2. Activity Result Launcher for runtime permissions
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val writeGranted = permissions[Manifest.permission.WRITE_CALL_LOG] == true
        val readGranted = permissions[Manifest.permission.READ_CALL_LOG] == true

        if (writeGranted && readGranted) {
            performInjection()
        } else {
            isSuccess = false
            statusText = "Permissions denied! WRITE_CALL_LOG and READ_CALL_LOG are required to insert call records into the system database."
            Toast.makeText(
                context,
                "Call Log permissions are required to inject calls.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Call Log Injector",
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Text(
                text = "Generate and insert simulated outgoing call logs directly into the native Android telephony provider.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // Target Phone Number Input
            OutlinedTextField(
                value = targetNumber,
                onValueChange = { targetNumber = it },
                label = { Text("Target Phone Number") },
                placeholder = { Text("+1 (555) 000-0000") },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Phone,
                        contentDescription = "Phone Number Icon"
                    )
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            // Time Window Input (in hours)
            OutlinedTextField(
                value = hoursWindowText,
                onValueChange = { hoursWindowText = it.filter { char -> char.isDigit() } },
                label = { Text("Time Window (Hours in past)") },
                placeholder = { Text("e.g. 24") },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Schedule,
                        contentDescription = "Clock Icon"
                    )
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            // Call Count Input
            OutlinedTextField(
                value = callCountText,
                onValueChange = { callCountText = it.filter { char -> char.isDigit() } },
                label = { Text("Call Count (Number of calls)") },
                placeholder = { Text("e.g. 5") },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = "Call Count Icon"
                    )
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Action Button: Inject Fake Calls
            Button(
                onClick = {
                    // Check runtime permissions first
                    val hasWritePermission = ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.WRITE_CALL_LOG
                    ) == PackageManager.PERMISSION_GRANTED

                    val hasReadPermission = ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.READ_CALL_LOG
                    ) == PackageManager.PERMISSION_GRANTED

                    if (hasWritePermission && hasReadPermission) {
                        performInjection()
                    } else {
                        permissionLauncher.launch(permissionsToRequest)
                    }
                },
                enabled = !isProcessing,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                if (isProcessing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        color = Color.White,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text("Injecting...")
                } else {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Inject Fake Calls",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // Status Message Display Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = when (isSuccess) {
                        true -> Color(0xFFF0FDF4)
                        false -> Color(0xFFFEF2F2)
                        null -> Color(0xFFF8FAFC)
                    }
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Status",
                        tint = when (isSuccess) {
                            true -> Color(0xFF16A34A)
                            false -> Color(0xFFDC2626)
                            null -> Color(0xFF64748B)
                        },
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = statusText,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = when (isSuccess) {
                            true -> Color(0xFF15803D)
                            false -> Color(0xFFB91C1C)
                            null -> Color(0xFF334155)
                        }
                    )
                }
            }
        }
    }
}

// Data class to wrap injection outcome
data class InjectionResult(
    val isSuccess: Boolean,
    val message: String,
    val insertedCount: Int = 0
)

/**
 * 4. Call Log Injection Function
 * Injects simulated outgoing calls into the native Android ContentResolver CallLog.Calls URI.
 */
fun injectFakeCalls(
    context: Context,
    targetNumber: String,
    hoursWindow: Int,
    callCount: Int
): InjectionResult {
    val random = Random()
    val currentTimeMs = System.currentTimeMillis()
    val maxOffsetMs = hoursWindow.toLong() * 60 * 60 * 1000
    var successfulInserts = 0

    try {
        for (i in 1..callCount) {
            // Random offset within the requested time window
            val randomOffsetMs = if (maxOffsetMs > 0) {
                (random.nextDouble() * maxOffsetMs).toLong()
            } else {
                0L
            }
            val callTimestamp = currentTimeMs - randomOffsetMs

            // Random duration between 10 and 120 seconds
            val callDuration = 10 + random.nextInt(111) // 10..120

            val values = ContentValues().apply {
                put(CallLog.Calls.NUMBER, targetNumber)
                put(CallLog.Calls.DATE, callTimestamp)
                put(CallLog.Calls.DURATION, callDuration.toLong())
                put(CallLog.Calls.TYPE, CallLog.Calls.OUTGOING_TYPE)
                put(CallLog.Calls.IS_READ, 1)

                // Gracefully handle deprecated or API-dependent fields
                // On API < 31, NEW was commonly set to 1 or 0; IS_READ is standard across Android 7+ (API 24+)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    put(CallLog.Calls.NEW, 0)
                }
            }

            // Insert into native Android CallLog telephony ContentProvider
            val uri = context.contentResolver.insert(CallLog.Calls.CONTENT_URI, values)
            if (uri != null) {
                successfulInserts++
            }
        }

        return InjectionResult(
            isSuccess = true,
            message = "Successfully added $successfulInserts calls into system Call Log!",
            insertedCount = successfulInserts
        )
    } catch (e: SecurityException) {
        return InjectionResult(
            isSuccess = false,
            message = "SecurityException: WRITE_CALL_LOG permission not granted. " + (e.localizedMessage ?: "")
        )
    } catch (e: IllegalArgumentException) {
        return InjectionResult(
            isSuccess = false,
            message = "IllegalArgumentException: Invalid CallLog values or unsupported column. " + (e.localizedMessage ?: "")
        )
    } catch (e: Exception) {
        return InjectionResult(
            isSuccess = false,
            message = "Error during insertion: " + (e.localizedMessage ?: e.javaClass.simpleName)
        )
    }
}
